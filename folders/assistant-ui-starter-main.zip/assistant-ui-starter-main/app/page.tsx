import { Assistant } from "./assistant";

export default function Home() {
  return <Assistant />;
}
